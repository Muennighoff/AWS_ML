from setuptools import setup

setup(name='ProbDists_nm',
      version='0.3',
      description='Gaussian/Binomial distributions',
      packages=['ProbDists_nm'],
      author='Niklas Muennighoff',
      author_email='n.muennighoff@gmail.com',
      zip_safe=False)
